import pathlib

TESTS_DIR = pathlib.Path(__file__).parent
FIXTURES_DIR = TESTS_DIR / "fixtures"
